﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem6.TrafficLights
{
    public enum Light
    {
        Red,
        Green,
        Yellow
    }
}
