﻿using System;

namespace _03BarracksFactory.CustomAttribute
{
    public class InjectAttribute : Attribute
    {
    }
}
