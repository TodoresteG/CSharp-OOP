﻿using System;

[SoftUni("Ventsi")]
class StartUp
{
    [SoftUni("Gosho")]
    static void Main(string[] args)
    {
    }
}


