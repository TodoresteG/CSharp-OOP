﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Problem7.InfernoInfinity.Enums
{
    public enum WeaponRarity
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
