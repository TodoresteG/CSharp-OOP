﻿namespace Problem8.MilitaryElite.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
