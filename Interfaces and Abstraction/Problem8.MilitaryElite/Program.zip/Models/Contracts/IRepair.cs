﻿namespace Problem8.MilitaryElite.Models.Contracts
{
    public interface IRepair
    {
        string PartName { get; }

        int HoursWorked { get; }
    }
}
