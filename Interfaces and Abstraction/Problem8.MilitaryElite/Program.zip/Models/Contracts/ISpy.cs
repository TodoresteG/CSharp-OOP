﻿namespace Problem8.MilitaryElite.Models.Contracts
{
    public interface ISpy : ISoldier
    {
        int CodeNumber { get; }
    }
}
