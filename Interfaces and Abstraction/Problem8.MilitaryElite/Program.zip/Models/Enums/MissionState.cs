﻿namespace Problem8.MilitaryElite.Models.Enums
{
    public enum MissionState
    {
        inProgress = 0,
        Finished = 1
    }
}
