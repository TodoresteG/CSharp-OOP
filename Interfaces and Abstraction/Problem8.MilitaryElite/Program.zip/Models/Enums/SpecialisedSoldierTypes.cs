﻿namespace Problem8.MilitaryElite.Models.Enums
{
    public enum SpecialisedSoldierTypes
    {
        Airforces = 0,
        Marines = 1
    }
}
