﻿namespace Problem8.MilitaryElite.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
